# jQuery MSG Plugin CHANGELOG

## 1.0.7

* Add package.json for new jquery plugin site



## 1.0.6

* Syntax tuning



## 1.0.5

* Fix bug on $.msg('replace') arg type



## 1.0.4

* Syntax tuning, no more array arguments for `Methods`
* Fix typo



## 1.0.3

* Move cache DOM el position



## 1.0.2

* Update PIE.htc for IE9



## 1.0.1

* Cancel preloading background image



## 1.0.0

* First stable release